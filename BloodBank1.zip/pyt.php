<?php
    $my_command = escapeshellcmd('python 1.py');
    $command_output = shell_exec($my_command);
    echo $command_output;
 ?>
